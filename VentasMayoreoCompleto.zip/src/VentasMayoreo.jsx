
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Send, RefreshCcw } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export default function VentasMayoreo() {
  const [productos, setProductos] = useState([]);
  const [filtro, setFiltro] = useState("");
  const [carrito, setCarrito] = useState([]);

  useEffect(() => {
    cargarProductosDesdeDrive();
  }, []);

  const cargarProductosDesdeDrive = async () => {
    try {
      const response = await fetch("https://opensheet.elk.sh/1S7pRnX-N0mfTR6P5pspvwmU7wvEzqoAt/Hoja1");
      const data = await response.json();
      const productosFormateados = data.map((item) => ({
        codigo: item.CODIGO || "",
        descripcion: item.DESCRIPCION || "",
        existencia: parseInt(item.EXISTENCIA || 0),
        precio: parseFloat(item.PRECIO || 0)
      }));
      setProductos(productosFormateados);
    } catch (error) {
      console.error("Error cargando productos:", error);
    }
  };

  const agregarProducto = (producto) => {
    const existe = carrito.find((p) => p.codigo === producto.codigo);
    if (!existe) setCarrito([...carrito, { ...producto, cantidad: 1 }]);
  };

  const generarPDF = () => {
    const doc = new jsPDF();
    doc.text("Cotización de Pedido", 14, 20);
    const rows = carrito.map((item) => [item.codigo, item.descripcion, item.cantidad, `L. ${item.precio.toFixed(2)}`]);
    autoTable(doc, {
      startY: 30,
      head: [["Código", "Descripción", "Cantidad", "Precio"]],
      body: rows,
    });
    doc.save("pedido.pdf");
  };

  const enviarWhatsApp = () => {
    let mensaje = "Pedido:\n";
    carrito.forEach((item) => {
      mensaje += `${item.descripcion} x${item.cantidad} - L. ${item.precio.toFixed(2)}\n`;
    });
    const url = `https://wa.me/?text=${encodeURIComponent(mensaje)}`;
    window.open(url, "_blank");
  };

  const filtrarProductos = productos.filter((p) =>
    p.descripcion.toLowerCase().includes(filtro.toLowerCase()) ||
    p.codigo.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className="p-4 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <div className="md:col-span-2">
        <div className="flex gap-2 mb-4">
          <Input
            placeholder="Buscar por código o descripción"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <Button onClick={cargarProductosDesdeDrive} variant="outline">
            <RefreshCcw className="w-4 h-4 mr-1" />Actualizar
          </Button>
        </div>
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
          {filtrarProductos.map((prod) => (
            <Card key={prod.codigo} className="rounded-2xl shadow-md">
              <CardContent className="p-4">
                <p><strong>Código:</strong> {prod.codigo}</p>
                <p><strong>Descripción:</strong> {prod.descripcion}</p>
                <p><strong>Existencia:</strong> {prod.existencia} unidades</p>
                <p><strong>Precio:</strong> L. {prod.precio.toFixed(2)}</p>
                <Button className="mt-2" onClick={() => agregarProducto(prod)}>Agregar</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-2">Cotización</h2>
        <div className="space-y-2">
          {carrito.map((item) => (
            <div key={item.codigo} className="border p-2 rounded-lg">
              <p>{item.descripcion} (x{item.cantidad})</p>
              <p className="text-sm text-muted">L. {item.precio.toFixed(2)}</p>
            </div>
          ))}
        </div>
        {carrito.length > 0 && (
          <div className="mt-4 flex gap-2">
            <Button variant="outline" onClick={generarPDF}><Download className="mr-2 h-4 w-4" />PDF</Button>
            <Button onClick={enviarWhatsApp}><Send className="mr-2 h-4 w-4" />WhatsApp</Button>
          </div>
        )}
      </div>
    </div>
  );
}
