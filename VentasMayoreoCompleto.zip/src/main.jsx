import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import VentasMayoreo from './VentasMayoreo';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <VentasMayoreo />
  </React.StrictMode>
);
